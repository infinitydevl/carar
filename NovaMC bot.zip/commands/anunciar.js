const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('anunciar')
    .setDescription('Cria e envia uma embed personalizada')
    .addStringOption(option => 
      option.setName('titulo')
        .setDescription('Título da Embed')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('descricao')
        .setDescription('Descrição da Embed')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('cor')
        .setDescription('Cor da Embed (Hexadecimal, ex: #ff0000)')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('imagem')
        .setDescription('URL da Imagem')
        .setRequired(false)),

  async execute(interaction) {
    try {
      // Verifica se o usuário tem o cargo necessário
      const requiredRole = '1356141451989483771'; 
      if (!interaction.member.roles.cache.some(role => role.id === requiredRole)) {
        return await interaction.reply({ content: 'Você não tem permissão para usar este comando.', ephemeral: true });
      }

      console.log(`[LOG] Comando /anunciar executado por ${interaction.user.tag}`);
      
      const title = interaction.options.getString('titulo');
      const description = interaction.options.getString('descricao');
      const color = interaction.options.getString('cor') || '#ffffff';
      const imageUrl = interaction.options.getString('imagem') || ''; 
      
      console.log(`[LOG] Dados recebidos: Título=${title}, Descrição=${description}, Cor=${color}, Imagem=${imageUrl}`);
      
      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color.replace('#', '') || 'FFFFFF')
        .setFooter({ text: '© Copyright: NovaMC' });
      
      if (imageUrl) embed.setImage(imageUrl);

      // Oculta a resposta do comando e envia a embed anonimamente no canal
      await interaction.deferReply({ ephemeral: true });
      await interaction.deleteReply(); // Remove qualquer resposta do bot
      await interaction.channel.send({ embeds: [embed] });

      console.log(`[LOG] Embed enviada anonimamente no canal ${interaction.channel.id}`);
    } catch (error) {
      console.error('[ERRO] Falha ao executar o comando:', error);
      await interaction.reply({ content: 'Erro ao criar a embed. Verifique o console.', ephemeral: true });
    }
  }
};
