const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('🔍 Exibe informações detalhadas de um usuário.')
    .addUserOption(option =>
      option
        .setName('usuario')
        .setDescription('Selecione o usuário para exibir as informações.')
        .setRequired(false)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('usuario') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`👤 Informações de ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🆔 ID', value: user.id, inline: true },
        { name: '📛 Apelido', value: member.nickname || 'Nenhum', inline: true },
        { name: '🧑‍🔧 Cargos', value: member.roles.cache.map(role => role.name).join(', ') || 'Nenhum', inline: false },
        { name: '📅 Entrou no servidor', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: false },
        { name: '📝 Conta criada em', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`, inline: false }
      )
      .setFooter({ text: 'Solicitado por ' + interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};