const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botconfig')
    .setDescription('Configure o bot através de um painel interativo.'),
  
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Configuração do Bot')
      .setDescription('Escolha uma das opções abaixo para configurar o bot:')
      .setColor('Blue')
      .setFooter({ text: `Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('change_name')
        .setLabel('Alterar Nome')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('change_avatar')
        .setLabel('Alterar Foto')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('change_owner')
        .setLabel('Alterar Dono')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('change_banner')
        .setLabel('Alterar Banner')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({ embeds: [embed], components: [buttons], ephemeral: true });
  },
};