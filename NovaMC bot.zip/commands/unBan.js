const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { ownerId } = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('[🔓] Remove o banimento de um usuário.')
        .addStringOption(option =>
            option.setName('userid')
                .setDescription('[🆔] ID do usuário a ser desbanido.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('motivo')
                .setDescription('[✏️] Motivo do desbanimento.')
        ), 

    async execute(interaction) {
        const userId = interaction.options.getString('userid');
        const reason = interaction.options.getString('motivo') || 'Não especificado';

        if (!ownerId.includes(interaction.user.id)) {
            return interaction.reply({ 
                content: '❌ Você não tem permissão para usar este comando.', 
                ephemeral: true 
            });
        }

        try {
            const user = await interaction.client.users.fetch(userId);
            await interaction.guild.members.unban(userId, reason);

            const embed = new EmbedBuilder()
                .setTitle('✅ Usuário Desbanido')
                .setColor('Green')
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: 'Usuário', value: `<@${userId}>`, inline: true },
                    { name: 'Motivo', value: reason, inline: true }
                ) 
                .setFooter({ text: `Desbanido por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) { 
            console.error(error);
            await interaction.reply({ 
                content: `❌ Não foi possível desbanir o usuário. Verifique se o ID está correto ou se o usuário está banido.`, 
                ephemeral: true 
            });
        } 
    },
};