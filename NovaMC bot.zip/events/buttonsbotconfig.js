const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'interactionCreate',

  async execute(interaction, client) {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;


    if (interaction.customId === 'change_name') {
      const modal = new ModalBuilder()
        .setCustomId('modal_change_name')
        .setTitle('Alterar Nome do Bot');
// criador: @nerydev
      const input = new TextInputBuilder()
        .setCustomId('bot_name_input')
        .setLabel('Digite o novo nome do bot (2-32 caracteres)')
        .setStyle(TextInputStyle.Short)
        .setMaxLength(32)
        .setMinLength(2)
        .setPlaceholder('Novo nome do bot')
        .setRequired(true);

      const row = new ActionRowBuilder().addComponents(input);
      modal.addComponents(row);

      await interaction.showModal(modal);
    }

    if (interaction.customId === 'modal_change_name') {
      const botName = interaction.fields.getTextInputValue('bot_name_input');

      try {
        await client.user.setUsername(botName);
        await interaction.reply({ content: `✅ O nome do bot foi alterado para: **${botName}**.`, ephemeral: true });
      } catch (error) {
        console.error(error);
        await interaction.reply({ content: '❌ Não foi possível alterar o nome do bot. Tente novamente mais tarde.', ephemeral: true });
      }
    }


    if (interaction.customId === 'change_avatar') {
      const modal = new ModalBuilder()
        .setCustomId('modal_change_avatar')
        .setTitle('Alterar Foto do Bot');

      const input = new TextInputBuilder()
        .setCustomId('bot_avatar_input')
        .setLabel('Link da nova foto do bot')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://exemplo.com/imagem.png')
        .setRequired(true);

      const row = new ActionRowBuilder().addComponents(input);
      modal.addComponents(row);

      await interaction.showModal(modal);
    }

    if (interaction.customId === 'modal_change_avatar') {
      const avatarURL = interaction.fields.getTextInputValue('bot_avatar_input');

      if (!avatarURL.startsWith('http://') && !avatarURL.startsWith('https://')) {
        await interaction.reply({ content: '❌ O link da foto precisa começar com "http://" ou "https://".', ephemeral: true });
        return;
      }

      try {
        await client.user.setAvatar(avatarURL);
        await interaction.reply({ content: '✅ A foto do bot foi alterada com sucesso!', ephemeral: true });
      } catch (error) {
        console.error(error);
        await interaction.reply({ content: '❌ Não foi possível alterar a foto do bot. Tente novamente mais tarde.', ephemeral: true });
      }
    }
// criador: @nerydev

    if (interaction.customId === 'change_banner') {
      const modal = new ModalBuilder()
        .setCustomId('modal_change_banner')
        .setTitle('Alterar Banner do Bot');

      const input = new TextInputBuilder()
        .setCustomId('bot_banner_input')
        .setLabel('Link do novo banner do bot')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://exemplo.com/banner.png')
        .setRequired(true);

      const row = new ActionRowBuilder().addComponents(input);
      modal.addComponents(row);

      await interaction.showModal(modal);
    }

    if (interaction.customId === 'modal_change_banner') {
      const bannerLink = interaction.fields.getTextInputValue('bot_banner_input');

      if (!bannerLink.startsWith('http://') && !bannerLink.startsWith('https://')) {
        await interaction.reply({ content: '❌ O link do banner precisa começar com "http://" ou "https://".', ephemeral: true });
        return;
      }

      await interaction.reply({ content: `✅ O banner do bot foi alterado com o link: ${bannerLink}.`, ephemeral: true });
    }


    if (interaction.customId === 'change_owner') {
      const modalEmbed = new EmbedBuilder()
        .setColor('Red')
        .setDescription('Mencione o novo dono do bot.');

      await interaction.reply({ embeds: [modalEmbed], ephemeral: true });

      const filter = m => m.author.id === interaction.user.id;
      const collector = interaction.channel.createMessageCollector({ filter, time: 60000 });

      collector.on('collect', async message => {
        const newOwner = message.mentions.users.first();

        if (!newOwner) {
          await interaction.followUp({ content: '❌ Você precisa mencionar um usuário válido.', ephemeral: true });
        } else {
          await interaction.followUp({ content: `✅ O novo dono do bot é: **${newOwner.tag}**.`, ephemeral: true });
        }
        collector.stop();
      }); // criador: @nerydev
    }
  },
};